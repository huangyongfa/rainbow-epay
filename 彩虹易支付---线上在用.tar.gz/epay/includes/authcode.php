<?php
define('authcode','c49994f8bd40cd62b6c1f952b40dfbf3');

?>