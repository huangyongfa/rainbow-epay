﻿<html>



<head>

<meta http-equiv="Content-Language" content="zh-cn">
正在跳转……
<meta http-equiv="Content-Type" content="text/html; charset=utf8">

<script language="javascript"> 

<!--  

location.replace("https://www.ch-h.cn/"); 

--> 

</script> 



</body>



</html>