<?php
return [
	'mchid'			=> trim($channel['appid']),
	'apikey'		=> trim($channel['appkey']),
];